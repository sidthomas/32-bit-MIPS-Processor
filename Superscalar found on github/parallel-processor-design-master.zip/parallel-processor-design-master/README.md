Parallel-Processor-Design
=========================

To design a customized processor (using parallel processing concepts) for the application of document retrieval system. We developed a superscalar processor (with  an issue rate of 2) using verilog hdl, and an assembler for that processor using flex and bison.
